/*
 * WWU: CS145 Winter 2017, Assignment 3
 *
 * CS145LinkedList.java -- A skeleton for a basic generic
 * linked list.
 *
 * Author: Chris Reedy (Chris.Reedy@wwu.edu).
 */
public class CS145LinkedList<E> {

   /* The ListNode class for this list. */
   private class ListNode {
      E data;
      ListNode next;
     
      /* Construct a ListNode containing data. */
      ListNode(E data) {
         this.data = data;
         next = null;
      }
      
      /* Construct a ListNode containing data, setting the
       * next. */
      ListNode(E data, ListNode next) {
         this.data = data;
         this.next = next;
      }
   }

   /* The first ListNode in the List. */
   private ListNode front;
   
   /* Construct an empty list object. */
   public CS145LinkedList() {
      front = null;
   }

   /* Return the size (number of items) in this list. */
   public int size() {
      // TODO return size
      return 0;
   }
   
   /* Return true if this CS145LinkedList has no items.
    * (This is the same as the size equal to zero.) Return
    * false if the size is greater than zero. */
   public boolean isEmpty() {
      // TODO return true if the list is empty
      return false;
   }
   
   /* Add the given element, value,  to the end of the list. */
   public void add(E value) {
      if (front == null) {
         front = new ListNode(value);
      } else {
         ListNode current = front;
         while (current.next != null) {
            current = current.next;
         }
         current.next = new ListNode(value);
      }
   }
   
   /* Add the given element, value, to the list at the given index.
    * After this operation is complete, get(index) will return value.
    * This operation is only valid for 0 <= index <= size(). */
   public void add(int index, E value) {
      // TODO insert value at location index. See lecture notes.
   }
   
   /* Return the element of the list at the given index. This operation
    * is only valid for 0 <= index < size(). This operation does not modify
    * the list. */
   public E get(int index) {
      // TODO get the item at index index. See lecture notes.
      return null;
   } 
}